/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./components/FingerprintProvider.tsx":
/*!********************************************!*\
  !*** ./components/FingerprintProvider.tsx ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ FingerprintProvider),\n/* harmony export */   useFingerprint: () => (/* binding */ useFingerprint)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _fingerprintjs_fingerprintjs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @fingerprintjs/fingerprintjs */ \"@fingerprintjs/fingerprintjs\");\n/* harmony import */ var _fingerprintjs_fingerprintjs__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_fingerprintjs_fingerprintjs__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nconst FingerprintContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)({\n    fingerprint: null,\n    isLoading: true,\n    error: null\n});\nconst useFingerprint = ()=>(0,react__WEBPACK_IMPORTED_MODULE_1__.useContext)(FingerprintContext);\nfunction FingerprintProvider({ children }) {\n    const [fingerprint, setFingerprint] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    const [isLoading, setIsLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(true);\n    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(null);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)({\n        \"FingerprintProvider.useEffect\": ()=>{\n            const initFingerprint = {\n                \"FingerprintProvider.useEffect.initFingerprint\": async ()=>{\n                    try {\n                        const fp = await _fingerprintjs_fingerprintjs__WEBPACK_IMPORTED_MODULE_2___default().load();\n                        const result = await fp.get();\n                        // Check if fingerprint is valid (not null/undefined)\n                        if (result.visitorId && result.visitorId !== 'null' && result.visitorId !== 'undefined') {\n                            setFingerprint(result.visitorId);\n                        } else {\n                            setError('Fingerprint not available (incognito mode or browser blocking)');\n                        }\n                    } catch (err) {\n                        console.error('Fingerprint error:', err);\n                        setError('Failed to generate device fingerprint - incognito mode detected');\n                    } finally{\n                        setIsLoading(false);\n                    }\n                }\n            }[\"FingerprintProvider.useEffect.initFingerprint\"];\n            initFingerprint();\n        }\n    }[\"FingerprintProvider.useEffect\"], []);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(FingerprintContext.Provider, {\n        value: {\n            fingerprint,\n            isLoading,\n            error\n        },\n        children: children\n    }, void 0, false, {\n        fileName: \"/Users/vivek/dev/projects/NextJs/bioascension/components/FingerprintProvider.tsx\",\n        lineNumber: 51,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9jb21wb25lbnRzL0ZpbmdlcnByaW50UHJvdmlkZXIudHN4IiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUF1RTtBQUNkO0FBUXpELE1BQU1LLG1DQUFxQkgsb0RBQWFBLENBQXlCO0lBQy9ESSxhQUFhO0lBQ2JDLFdBQVc7SUFDWEMsT0FBTztBQUNUO0FBRU8sTUFBTUMsaUJBQWlCLElBQU1OLGlEQUFVQSxDQUFDRSxvQkFBb0I7QUFNcEQsU0FBU0ssb0JBQW9CLEVBQUVDLFFBQVEsRUFBNEI7SUFDaEYsTUFBTSxDQUFDTCxhQUFhTSxlQUFlLEdBQUdYLCtDQUFRQSxDQUFnQjtJQUM5RCxNQUFNLENBQUNNLFdBQVdNLGFBQWEsR0FBR1osK0NBQVFBLENBQUM7SUFDM0MsTUFBTSxDQUFDTyxPQUFPTSxTQUFTLEdBQUdiLCtDQUFRQSxDQUFnQjtJQUVsREQsZ0RBQVNBO3lDQUFDO1lBQ1IsTUFBTWU7aUVBQWtCO29CQUN0QixJQUFJO3dCQUNGLE1BQU1DLEtBQUssTUFBTVosd0VBQWtCO3dCQUNuQyxNQUFNYyxTQUFTLE1BQU1GLEdBQUdHLEdBQUc7d0JBRTNCLHFEQUFxRDt3QkFDckQsSUFBSUQsT0FBT0UsU0FBUyxJQUFJRixPQUFPRSxTQUFTLEtBQUssVUFBVUYsT0FBT0UsU0FBUyxLQUFLLGFBQWE7NEJBQ3ZGUixlQUFlTSxPQUFPRSxTQUFTO3dCQUNqQyxPQUFPOzRCQUNMTixTQUFTO3dCQUNYO29CQUNGLEVBQUUsT0FBT08sS0FBSzt3QkFDWkMsUUFBUWQsS0FBSyxDQUFDLHNCQUFzQmE7d0JBQ3BDUCxTQUFTO29CQUNYLFNBQVU7d0JBQ1JELGFBQWE7b0JBQ2Y7Z0JBQ0Y7O1lBRUFFO1FBQ0Y7d0NBQUcsRUFBRTtJQUVMLHFCQUNFLDhEQUFDVixtQkFBbUJrQixRQUFRO1FBQUNDLE9BQU87WUFBRWxCO1lBQWFDO1lBQVdDO1FBQU07a0JBQ2pFRzs7Ozs7O0FBR1AiLCJzb3VyY2VzIjpbIi9Vc2Vycy92aXZlay9kZXYvcHJvamVjdHMvTmV4dEpzL2Jpb2FzY2Vuc2lvbi9jb21wb25lbnRzL0ZpbmdlcnByaW50UHJvdmlkZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUsIGNyZWF0ZUNvbnRleHQsIHVzZUNvbnRleHQgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgRmluZ2VycHJpbnRKUyBmcm9tICdAZmluZ2VycHJpbnRqcy9maW5nZXJwcmludGpzJztcblxuaW50ZXJmYWNlIEZpbmdlcnByaW50Q29udGV4dFR5cGUge1xuICBmaW5nZXJwcmludDogc3RyaW5nIHwgbnVsbDtcbiAgaXNMb2FkaW5nOiBib29sZWFuO1xuICBlcnJvcjogc3RyaW5nIHwgbnVsbDtcbn1cblxuY29uc3QgRmluZ2VycHJpbnRDb250ZXh0ID0gY3JlYXRlQ29udGV4dDxGaW5nZXJwcmludENvbnRleHRUeXBlPih7XG4gIGZpbmdlcnByaW50OiBudWxsLFxuICBpc0xvYWRpbmc6IHRydWUsXG4gIGVycm9yOiBudWxsLFxufSk7XG5cbmV4cG9ydCBjb25zdCB1c2VGaW5nZXJwcmludCA9ICgpID0+IHVzZUNvbnRleHQoRmluZ2VycHJpbnRDb250ZXh0KTtcblxuaW50ZXJmYWNlIEZpbmdlcnByaW50UHJvdmlkZXJQcm9wcyB7XG4gIGNoaWxkcmVuOiBSZWFjdC5SZWFjdE5vZGU7XG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEZpbmdlcnByaW50UHJvdmlkZXIoeyBjaGlsZHJlbiB9OiBGaW5nZXJwcmludFByb3ZpZGVyUHJvcHMpIHtcbiAgY29uc3QgW2ZpbmdlcnByaW50LCBzZXRGaW5nZXJwcmludF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpO1xuICBjb25zdCBbZXJyb3IsIHNldEVycm9yXSA9IHVzZVN0YXRlPHN0cmluZyB8IG51bGw+KG51bGwpO1xuXG4gIHVzZUVmZmVjdCgoKSA9PiB7XG4gICAgY29uc3QgaW5pdEZpbmdlcnByaW50ID0gYXN5bmMgKCkgPT4ge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgZnAgPSBhd2FpdCBGaW5nZXJwcmludEpTLmxvYWQoKTtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgZnAuZ2V0KCk7XG4gICAgICAgIFxuICAgICAgICAvLyBDaGVjayBpZiBmaW5nZXJwcmludCBpcyB2YWxpZCAobm90IG51bGwvdW5kZWZpbmVkKVxuICAgICAgICBpZiAocmVzdWx0LnZpc2l0b3JJZCAmJiByZXN1bHQudmlzaXRvcklkICE9PSAnbnVsbCcgJiYgcmVzdWx0LnZpc2l0b3JJZCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICBzZXRGaW5nZXJwcmludChyZXN1bHQudmlzaXRvcklkKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICBzZXRFcnJvcignRmluZ2VycHJpbnQgbm90IGF2YWlsYWJsZSAoaW5jb2duaXRvIG1vZGUgb3IgYnJvd3NlciBibG9ja2luZyknKTtcbiAgICAgICAgfVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0ZpbmdlcnByaW50IGVycm9yOicsIGVycik7XG4gICAgICAgIHNldEVycm9yKCdGYWlsZWQgdG8gZ2VuZXJhdGUgZGV2aWNlIGZpbmdlcnByaW50IC0gaW5jb2duaXRvIG1vZGUgZGV0ZWN0ZWQnKTtcbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIHNldElzTG9hZGluZyhmYWxzZSk7XG4gICAgICB9XG4gICAgfTtcblxuICAgIGluaXRGaW5nZXJwcmludCgpO1xuICB9LCBbXSk7XG5cbiAgcmV0dXJuIChcbiAgICA8RmluZ2VycHJpbnRDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IGZpbmdlcnByaW50LCBpc0xvYWRpbmcsIGVycm9yIH19PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvRmluZ2VycHJpbnRDb250ZXh0LlByb3ZpZGVyPlxuICApO1xufSAiXSwibmFtZXMiOlsidXNlRWZmZWN0IiwidXNlU3RhdGUiLCJjcmVhdGVDb250ZXh0IiwidXNlQ29udGV4dCIsIkZpbmdlcnByaW50SlMiLCJGaW5nZXJwcmludENvbnRleHQiLCJmaW5nZXJwcmludCIsImlzTG9hZGluZyIsImVycm9yIiwidXNlRmluZ2VycHJpbnQiLCJGaW5nZXJwcmludFByb3ZpZGVyIiwiY2hpbGRyZW4iLCJzZXRGaW5nZXJwcmludCIsInNldElzTG9hZGluZyIsInNldEVycm9yIiwiaW5pdEZpbmdlcnByaW50IiwiZnAiLCJsb2FkIiwicmVzdWx0IiwiZ2V0IiwidmlzaXRvcklkIiwiZXJyIiwiY29uc29sZSIsIlByb3ZpZGVyIiwidmFsdWUiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./components/FingerprintProvider.tsx\n");

/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _components_FingerprintProvider__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../components/FingerprintProvider */ \"./components/FingerprintProvider.tsx\");\n\n\n\nfunction App({ Component, pageProps }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_components_FingerprintProvider__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"/Users/vivek/dev/projects/NextJs/bioascension/pages/_app.tsx\",\n            lineNumber: 7,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"/Users/vivek/dev/projects/NextJs/bioascension/pages/_app.tsx\",\n        lineNumber: 6,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQStCO0FBQ3FDO0FBRXJELFNBQVNDLElBQUksRUFBRUMsU0FBUyxFQUFFQyxTQUFTLEVBQUU7SUFDbEQscUJBQ0UsOERBQUNILHVFQUFtQkE7a0JBQ2xCLDRFQUFDRTtZQUFXLEdBQUdDLFNBQVM7Ozs7Ozs7Ozs7O0FBRzlCIiwic291cmNlcyI6WyIvVXNlcnMvdml2ZWsvZGV2L3Byb2plY3RzL05leHRKcy9iaW9hc2NlbnNpb24vcGFnZXMvX2FwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0ICcuLi9zdHlsZXMvZ2xvYmFscy5jc3MnO1xuaW1wb3J0IEZpbmdlcnByaW50UHJvdmlkZXIgZnJvbSAnLi4vY29tcG9uZW50cy9GaW5nZXJwcmludFByb3ZpZGVyJztcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gQXBwKHsgQ29tcG9uZW50LCBwYWdlUHJvcHMgfSkge1xuICByZXR1cm4gKFxuICAgIDxGaW5nZXJwcmludFByb3ZpZGVyPlxuICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSAvPlxuICAgIDwvRmluZ2VycHJpbnRQcm92aWRlcj5cbiAgKTtcbn0gIl0sIm5hbWVzIjpbIkZpbmdlcnByaW50UHJvdmlkZXIiLCJBcHAiLCJDb21wb25lbnQiLCJwYWdlUHJvcHMiXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.tsx\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "@fingerprintjs/fingerprintjs":
/*!***********************************************!*\
  !*** external "@fingerprintjs/fingerprintjs" ***!
  \***********************************************/
/***/ ((module) => {

"use strict";
module.exports = require("@fingerprintjs/fingerprintjs");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.tsx"));
module.exports = __webpack_exports__;

})();