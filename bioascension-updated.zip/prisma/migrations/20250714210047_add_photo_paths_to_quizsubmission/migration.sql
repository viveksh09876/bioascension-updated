-- AlterTable
ALTER TABLE "quiz_submissions" ADD COLUMN     "photo1YearAgoBody" TEXT,
ADD COLUMN     "photo1YearAgoFront" TEXT,
ADD COLUMN     "photo1YearAgoSide" TEXT,
ADD COLUMN     "photoNowBody" TEXT,
ADD COLUMN     "photoNowFront" TEXT,
ADD COLUMN     "photoNowSide" TEXT;
